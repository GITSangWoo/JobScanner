package com.team2.jobscanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobscannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobscannerApplication.class, args);
	}

}
