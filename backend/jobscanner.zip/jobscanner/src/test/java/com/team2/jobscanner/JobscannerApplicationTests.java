package com.team2.jobscanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobscannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
